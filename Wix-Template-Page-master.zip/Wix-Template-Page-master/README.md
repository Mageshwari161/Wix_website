# Wix-Template-Page

Wix Template Page (using HTML 5 , CSS 3 and JavaScript)

Preview: https://mohammed-raafat.github.io/Wix-Template-Page/

This was an application on Web Design course from Unique Coderz Academy: https://www.youtube.com/channel/UCq_xgufsy1KrGsmJq7mFH-g
